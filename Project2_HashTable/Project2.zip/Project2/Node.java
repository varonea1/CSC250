/********************************************************
*  Name      : Adam Varone
*  Course    : CSC 250-01
*  Date      : Spring 2019
*  Professor : DeGood
*
*  Assignment: Project 2
*
*  This is the Node class it is the object node which has a SSN, a name, and a node that points to next.
********************************************************/

public class Node {
    String SSN;
    String name;
    Node next;
}
